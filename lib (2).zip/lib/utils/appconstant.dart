 class AppConstant{
   static const String BASE_URL = "http://kolacut.kvpscampuscare.com/";
   static const String SEND_OTP="public/api/login";
   //public/api/login
   static const String REGISTER="public/api/register";
   static const String VERIFY_OTP="public/api/verify-otp";
   static const String GET_PROFILE="public/api/get-profile";
   static const String UPDATE_PROFILE="public/api/update-profile";
   static const String SHOP_DETAIL="public/api/shopDetail";
   static const String SHOP_LIST="public/api/shop-list";
   static const String WISHLIST="public/api/favorite-list";
   static const String SERVICE_LIST="public/api/shop-service";
   static const ADD_REMOVE_FAVOURITE="public/api/make-favorite";
   static const BOOK_SERVICE="public/api/add-booking";
   static const ALL_BOOKINGS="public/api/all-bookings";
   static const ADMIN_COUPON_LIST="public/api/get-coupon";
   static const COIN="public/api/get-coin";
}