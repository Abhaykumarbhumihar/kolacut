import 'dart:collection';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/state_manager.dart';
import 'package:intl/intl.dart';
import 'package:kolacut_employee/screens/applyleave.dart';
import 'package:kolacut_employee/utils/CommomDialog.dart';
import '../utils/Utils.dart';
import 'package:cell_calendar/cell_calendar.dart';
import '../controller/LeaveApplyController.dart';
import 'package:get/get.dart';

class TableBasicsExample extends StatefulWidget {
  @override
  _TableBasicsExampleState createState() => _TableBasicsExampleState();
}

class _TableBasicsExampleState extends State<TableBasicsExample> {
  LeaveApplyController leaveapplyController = Get.put(LeaveApplyController());
  List<CalendarEvent> sampleEvents = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final cellCalendarPageController = CellCalendarPageController();
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0.0,
          automaticallyImplyLeading: false,
          titleSpacing: 0,
          centerTitle: false,
          leading: GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(
                Icons.arrow_back,
                color: Colors.black,
              )),
          title: Text(
            'Leave Management',
            style: TextStyle(
                color: Colors.black,
                fontFamily: 'Poppins Medium',
                fontSize: width * 0.04),
          ),
        ),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.add),
          onPressed: () {
            CommonDialog.showBottomSheet();
          },
        ),
        body: GetBuilder<LeaveApplyController>(builder: (leaveapplyController) {
          if (leaveapplyController.lodaer) {
            return Container();
          } else {
            init:
            LeaveApplyController();
            sampleEvents.clear();
            leaveapplyController.leaveApplyPojo.value.data!.forEach((element) {
              sampleEvents.add(CalendarEvent(
                  eventName: element.holidayType.toString(),
                  eventDate: element!.calenderDate!,
                  eventBackgroundColor:
                      element.holidayType.toString() == "Fully off"
                          ? Colors.cyan
                          : Colors.amber));
            });

            print(sampleEvents);
            return Container(
              width: width,
              height: height,
              child: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: height * 0.02,
                    ),
                    Divider(
                      height: 2,
                      color: Colors.grey,
                    ),
                    SizedBox(
                      height: height * 0.02,
                    ),
                    SizedBox(
                      height: height * 0.02,
                    ),
                    SizedBox(
                      height: height * 0.8,
                      width: width,
                      child: CellCalendar(
                        cellCalendarPageController: cellCalendarPageController,
                        events: sampleEvents,
                        daysOfTheWeekBuilder: (dayIndex) {
                          final labels = ["S", "M", "T", "W", "T", "F", "S"];
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 4.0),
                            child: Text(
                              labels[dayIndex],
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color:
                                      dayIndex == 0 ? Colors.red : Colors.black,
                                  fontSize: 10),
                              textAlign: TextAlign.center,
                            ),
                          );
                        },
                        monthYearLabelBuilder: (datetime) {
                          final year = datetime!.year.toString();
                          final month = datetime.month.monthName;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                const SizedBox(width: 16),
                                Text(
                                  "$month  $year",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const Spacer(),
                                IconButton(
                                  padding: EdgeInsets.zero,
                                  icon: Icon(
                                    Icons.calendar_today,
                                    size: 16,
                                  ),
                                  onPressed: () {
                                    cellCalendarPageController.animateToDate(
                                      DateTime.now(),
                                      curve: Curves.linear,
                                      duration: Duration(milliseconds: 300),
                                    );
                                  },
                                )
                              ],
                            ),
                          );
                        },
                        onCellTapped: (date) {
                          final eventsOnTheDate = sampleEvents.where((event) {
                            final eventDate = event.eventDate;
                            return eventDate.year == date.year &&
                                eventDate.month == date.month &&
                                eventDate.day == date.day;
                          }).toList();
                          showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                    title: Text(date.month.monthName +
                                        " " +
                                        date.day.toString()),
                                    content: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: eventsOnTheDate
                                          .map(
                                            (event) => Container(
                                              width: double.infinity,
                                              padding: EdgeInsets.all(4),
                                              margin:
                                                  EdgeInsets.only(bottom: 12),
                                              color: event.eventBackgroundColor,
                                              child: Text(
                                                event.eventName,
                                                style: TextStyle(
                                                    color:
                                                        event.eventTextColor),
                                              ),
                                            ),
                                          )
                                          .toList(),
                                    ),
                                  ));
                        },
                        onPageChanged: (firstDate, lastDate) {
                          /// Called when the page was changed
                          /// Fetch additional events by using the range between [firstDate] and [lastDate] if you want
                        },
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(width * 0.03),
                      width: width,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Holidays',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: width * 0.03,
                                    fontFamily: 'Poppins Medium'),
                              ),
                              Text(
                                'List of holidays except weekly holidays',
                                style: TextStyle(
                                    color: Color(
                                        Utils.hexStringToHexInt('A3A2A2')),
                                    fontSize: width * 0.02,
                                    fontFamily: 'Poppins Medium'),
                              ),
                            ],
                          ),
                          Container(
                            margin: EdgeInsets.only(right: width * 0.01),
                            child: SvgPicture.asset(
                              "images/svgicons/filtertext.svg",
                            ),
                          )
                        ],
                      ),
                    ),
                    recentleavelist(width, height, context)
                  ],
                ),
              ),
            );
          }
        })

        /////////////////////////////////////////////////////////////////////////////////
        );
  }

  Widget recentleavelist(width, height, contet) {
    return SizedBox(
      width: width,
      height: height * 0.5,
      child: ListView.builder(
          scrollDirection: Axis.vertical,
          shrinkWrap: true,
          itemCount: 2,
          itemBuilder: (context, position) {
            return Container(
              margin: EdgeInsets.only(
                  left: width * 0.04,
                  right: width * 0.04,
                  top: height * 0.03,
                  bottom: height * 0.03),
              child: Material(
                borderRadius: BorderRadius.circular(width * 0.04),
                elevation: 6,
                child: Container(
                  width: width,
                  height: height * 0.2 - height * 0.03,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(width * 0.04),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              SizedBox(
                                height: height * 0.004,
                              ),
                              Row(
                                children: <Widget>[
                                  Container(
                                    margin: EdgeInsets.only(left: width * 0.01),
                                    width: width * 0.2,
                                    height: height * 0.03,
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(width * 0.01),
                                        color: Color(Utils.hexStringToHexInt(
                                            '#ecfafb'))),
                                    child: Center(
                                      child: Text(
                                        'Full day off',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: Color(
                                                Utils.hexStringToHexInt(
                                                    '4285F4')),
                                            fontFamily: 'Poppins Regular',
                                            fontSize: width * 0.02),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: height * 0.003,
                              ),
                              Text(
                                ' May 01, 2021',
                                style: TextStyle(
                                    fontSize: width * 0.02,
                                    color: Color(
                                        Utils.hexStringToHexInt('8D8D8D')),
                                    fontFamily: 'Poppins Regular'),
                              ),
                              SizedBox(
                                height: height * 0.003,
                              ),
                              Text(
                                ' Emergency at the house',
                                style: TextStyle(
                                    fontSize: width * 0.03,
                                    color: Colors.black,
                                    fontFamily: 'Poppins Regular'),
                              ),
                              SizedBox(
                                height: height * 0.01,
                              )
                            ],
                          )
                        ],
                      ),
                      Container(
                        margin: EdgeInsets.only(right: width * 0.02),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              '',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: width * 0.01,
                                  fontFamily: 'Poppins Medium'),
                            ),
                            Container(
                              margin: EdgeInsets.only(right: width * 0.02),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Container(
                                    width: width * 0.2 - width * 0.09,
                                    height: height * 0.02,
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(width * 0.04),
                                        color: Color(
                                            Utils.hexStringToHexInt('4285F4'))),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          }),
    );
  }

  Widget mainData(width, height, cellCalendarPageController) {
    List<CalendarEvent> sampleEvents = [];
    leaveapplyController.leaveApplyPojo.value.data!.forEach((element) {
      sampleEvents.add(CalendarEvent(
          eventName: element.holidayType.toString(),
          eventDate: element!.calenderDate!,
          eventBackgroundColor: element.holidayType.toString() == "partialy_off"
              ? Colors.cyan
              : Colors.amber));
    });
    return Container(
      width: width,
      height: height,
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                Column(
                  children: <Widget>[
                    SizedBox(
                      height: height * 0.01,
                    ),
                    Divider(
                      height: 2,
                      color: Colors.grey,
                    ),
                    SizedBox(
                      height: height * 0.5,
                      width: width,
                      child: CellCalendar(
                        cellCalendarPageController: cellCalendarPageController,
                        events: sampleEvents,
                        daysOfTheWeekBuilder: (dayIndex) {
                          final labels = ["S", "M", "T", "W", "T", "F", "S"];
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 4.0),
                            child: Text(
                              labels[dayIndex],
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color:
                                      dayIndex == 0 ? Colors.red : Colors.black,
                                  fontSize: 10),
                              textAlign: TextAlign.center,
                            ),
                          );
                        },
                        monthYearLabelBuilder: (datetime) {
                          final year = datetime!.year.toString();
                          final month = datetime.month.monthName;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                const SizedBox(width: 16),
                                Text(
                                  "$month  $year",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const Spacer(),
                                IconButton(
                                  padding: EdgeInsets.zero,
                                  icon: Icon(
                                    Icons.calendar_today,
                                    size: 16,
                                  ),
                                  onPressed: () {
                                    cellCalendarPageController.animateToDate(
                                      DateTime.now(),
                                      curve: Curves.linear,
                                      duration: Duration(milliseconds: 300),
                                    );
                                  },
                                )
                              ],
                            ),
                          );
                        },
                        onCellTapped: (date) {
                          final eventsOnTheDate = sampleEvents.where((event) {
                            final eventDate = event.eventDate;
                            return eventDate.year == date.year &&
                                eventDate.month == date.month &&
                                eventDate.day == date.day;
                          }).toList();
                          showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                    title: Text(date.month.monthName +
                                        " " +
                                        date.day.toString()),
                                    content: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: eventsOnTheDate
                                          .map(
                                            (event) => Container(
                                              width: double.infinity,
                                              padding: EdgeInsets.all(4),
                                              margin:
                                                  EdgeInsets.only(bottom: 12),
                                              color: event.eventBackgroundColor,
                                              child: Text(
                                                event.eventName,
                                                style: TextStyle(
                                                    color:
                                                        event.eventTextColor),
                                              ),
                                            ),
                                          )
                                          .toList(),
                                    ),
                                  ));
                        },
                        onPageChanged: (firstDate, lastDate) {
                          /// Called when the page was changed
                          /// Fetch additional events by using the range between [firstDate] and [lastDate] if you want
                        },
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.all(width * 0.03),
                      width: width,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Holidays',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: width * 0.03,
                                    fontFamily: 'Poppins Medium'),
                              ),
                              Text(
                                'List of holidays except weekly holidays',
                                style: TextStyle(
                                    color: Color(
                                        Utils.hexStringToHexInt('A3A2A2')),
                                    fontSize: width * 0.02,
                                    fontFamily: 'Poppins Medium'),
                              ),
                            ],
                          ),
                          Container(
                            margin: EdgeInsets.only(right: width * 0.01),
                            child: SvgPicture.asset(
                              "images/svgicons/filtertext.svg",
                            ),
                          )
                        ],
                      ),
                    ),
                    recentleavelist(width, height, context),
                  ],
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
