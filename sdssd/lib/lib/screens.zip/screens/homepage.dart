import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/svg.dart';
import 'package:kolacut_employee/screens/allbooking.dart';

import '../utils/Utils.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return SafeArea(
      child: Container(
        width: width,
        height: height,

        child: Scaffold(
          resizeToAvoidBottomInset: true,
          appBar: AppBar(
            centerTitle: true,
            elevation: 0.0,
            backgroundColor: Colors.white,
            leading: Icon(
              Icons.menu,
              color: Colors.black,
            ),

            actions: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Container(
                    width: width * 0.03,
                    height: height * 0.03,

                    child: SvgPicture.asset(
                      "images/svgicons/mappin.svg",
                    ),
                  ),
                  Text(' Crossing Republick, Ghaziabad',
                      style: TextStyle(
                          fontSize: width * 0.02,
                          fontFamily: 'Poppins Regular',
                          color: Colors.black),
                      textAlign: TextAlign.center),
                  IconButton(
                    icon: Icon(
                      Icons.keyboard_arrow_down_sharp,
                      size: width * 0.04,
                      color: Colors.black,
                    ),
                    tooltip: 'Comment Icon',
                    onPressed: () {},
                  )
                ],
              ),
              Container(
                margin: EdgeInsets.only(right: width * 0.01),
                child: SvgPicture.asset(
                  "images/svgicons/filtersv.svg",
                ),
              )
            ],
          ),
          backgroundColor: Colors.transparent,
          body: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[


                Container(
                  margin: EdgeInsets.only(left: width*0.03,top: height*0.03),
                  child: Text(
                    'Hello Aparna',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: width * 0.04,
                        fontFamily: 'Poppins Regular'),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(left: width*0.03),
                  child: Text(
                    'Today’s Update',
                    style: TextStyle(
                        color: Color(Utils.hexStringToHexInt('C4C4C4')),
                        fontSize: width * 0.02,
                        fontFamily: 'Poppins Regular'),
                  ),
                ),

                Container(
                  margin: EdgeInsets.only(left: width*0.03,top: height*0.03,bottom: width*0.03 ),
                  child: Row(
                    children: <Widget>[
                      Material(
                        borderRadius: BorderRadius.circular(width * 0.04),
                        elevation: 12,
                        child: Container(
                          width: width * 0.4,
                          height: height * 0.1,
                          decoration: BoxDecoration(
                              borderRadius:
                              BorderRadius.circular(width * 0.04),
                              gradient: LinearGradient(
                                  begin: Alignment.topRight,
                                  end: Alignment.bottomLeft,
                                  colors: [
                                    Color(
                                        Utils.hexStringToHexInt('#76cbfb')),
                                    Color(
                                        Utils.hexStringToHexInt('#3ac1ca')),
                                    Color(
                                        Utils.hexStringToHexInt('#47c3d4')),
                                  ])),
                          child:
                          Container(
                            margin: EdgeInsets.only(left: width * 0.03),
                            child: Stack(
                              children: <Widget>[
                                Positioned(
                                  top: height * 0.01,
                                  child: Text(
                                    '20',
                                    style: TextStyle(
                                        fontFamily: 'Poppins Semibold',
                                        fontSize: MediaQuery.of(context)
                                            .size
                                            .height *
                                            0.03,
                                        color: Colors.white),
                                  ),
                                ),
                                Positioned(
                                  top: height * 0.06,
                                  child: Text(
                                    'Total Staff ',
                                    style: TextStyle(
                                        fontFamily: 'Poppins Semibold',
                                        fontSize: MediaQuery.of(context)
                                            .size
                                            .height *
                                            0.02 -
                                            height * 0.003,
                                        color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: width * 0.03,
                      ),
                      Material(
                        borderRadius: BorderRadius.circular(width * 0.04),
                        elevation: 12,
                        child: Container(
                          width: width * 0.4,
                          height: height * 0.1,
                          decoration: BoxDecoration(
                              borderRadius:
                              BorderRadius.circular(width * 0.04),
                              gradient: LinearGradient(
                                  begin: Alignment.topRight,
                                  end: Alignment.bottomLeft,
                                  colors: [
                                    Color(
                                        Utils.hexStringToHexInt('#0c5eed')),
                                    Color(
                                        Utils.hexStringToHexInt('#306ed9')),
                                    Color(
                                        Utils.hexStringToHexInt('#3f6dbd')),
                                  ])),
                          child: Container(
                            margin: EdgeInsets.only(left: width * 0.03),
                            child: Stack(
                              children: <Widget>[
                                Positioned(
                                  top: height * 0.01,
                                  child: Text(
                                    '20',
                                    style: TextStyle(
                                        fontFamily: 'Poppins Semibold',
                                        fontSize: MediaQuery.of(context)
                                            .size
                                            .height *
                                            0.03,
                                        color: Colors.white),
                                  ),
                                ),
                                Positioned(
                                  top: height * 0.06,
                                  child: Text(
                                    'Total Staff ',
                                    style: TextStyle(
                                        fontFamily: 'Poppins Semibold',
                                        fontSize: MediaQuery.of(context)
                                            .size
                                            .height *
                                            0.02 -
                                            height * 0.003,
                                        color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                Container(
                  margin: EdgeInsets.only(left: width*0.03),
                  child: Text(
                    'Bookings',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: width * 0.03,
                        fontFamily: 'Poppins Regular'),
                  ),
                ),

                bookinglist(width,height,context),
                recentleavelist(width,height,context),

                SizedBox(height: height*0.04,)
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget recentleavelist(width,height,contet){
    return  SizedBox(
      width: width,
      height: height*0.5,
      child: ListView.builder(
          scrollDirection: Axis.vertical,
          shrinkWrap: true,itemCount: 2,
          itemBuilder: (context,position){
            return Container(
              margin:
              EdgeInsets.only(left: width * 0.04, right: width * 0.04,
                  top: height*0.03,bottom: height*0.03),
              child: Material(
                borderRadius: BorderRadius.circular(width * 0.04),
                elevation: 6,
                child: Container(
                  width: width,
                  height: height * 0.2 - height * 0.03,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(width * 0.04),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[

                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              SizedBox(
                                height: height * 0.004,
                              ),
                              Row(
                                children: <Widget>[
                                  Container(
                                    margin:
                                    EdgeInsets.only(left: width * 0.01),
                                    width: width * 0.2,
                                    height: height * 0.03,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            width * 0.01),
                                        color: Color(
                                            Utils.hexStringToHexInt(
                                                '#ecfafb'))),
                                    child: Center(
                                      child: Text(
                                        'Full day off',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: Color(
                                                Utils.hexStringToHexInt(
                                                    '4285F4')),
                                            fontFamily: 'Poppins Regular',
                                            fontSize: width * 0.02),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: height*0.003,),
                              Text(
                                ' May 01, 2021',
                                style: TextStyle(
                                    fontSize: width * 0.02,
                                    color: Color(
                                        Utils.hexStringToHexInt('8D8D8D')),
                                    fontFamily: 'Poppins Regular'),
                              ),
                              SizedBox(
                                height: height * 0.003,
                              ),

                              Text(
                                ' Emergency at the house',
                                style: TextStyle(
                                    fontSize: width * 0.03,
                                    color: Colors.black,
                                    fontFamily: 'Poppins Regular'),
                              ),

                              SizedBox(
                                height: height * 0.01,
                              )
                            ],
                          )
                        ],
                      ),
                      Container(
                        margin: EdgeInsets.only(right: width * 0.02),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              '',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: width * 0.01,
                                  fontFamily: 'Poppins Medium'),
                            ),
                            Container(
                              margin: EdgeInsets.only(right: width * 0.02),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Container(
                                    width: width * 0.2 - width * 0.09,
                                    height: height * 0.02,
                                    decoration: BoxDecoration(
                                        borderRadius:
                                        BorderRadius.circular(width * 0.04),
                                        color: Color(
                                            Utils.hexStringToHexInt('4285F4'))),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            );
          }),
    );
  }

  Widget bookinglist(width,height,context){
    return  ListView.builder
      (
        physics: NeverScrollableScrollPhysics(),
        padding: EdgeInsets.all(5),
        shrinkWrap: true,
        itemCount: 3,
        scrollDirection: Axis.vertical,
        itemBuilder: (context,position){
          return  GestureDetector(
            onTap: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const AllBooking()),
              );
            },
            child: Container(
              width: width,
              child: Column(
                children: [
                  SizedBox(
                    height: height * 0.01,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(left: width * 0.03),
                            child: CircleAvatar(
                              radius: width * 0.07,
                              backgroundImage: NetworkImage(
                                  "https://images.unsplash.com/photo-1597466765990-64ad1c35dafc"),
                            ),
                          ),
                          SizedBox(
                            width: width * 0.02,
                          ),


                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Text(
                                    '839176',
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontFamily: 'Poppins Semibold',
                                        fontSize: width * 0.04),
                                  ),
                                  Container(
                                      padding: const EdgeInsets.all(3.0),


                                      decoration: BoxDecoration(
                                          image: DecorationImage(
                                              image: AssetImage(
                                                'images/svgicons/tagbackpn.png',
                                              ),
                                              fit: BoxFit.fitHeight)),
                                      child: Center(
                                        child: Container(
                                          margin: EdgeInsets.all(2.0),
                                          child: Text(
                                            'In Progress',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                fontSize: width*0.02,
                                                color: Colors.white,
                                                fontFamily: 'Poppins Regular'),
                                          ),
                                        ),
                                      ))
                                ],
                              ),
                              Text(
                                'Visit on 24 Jun, 10:00 AM',
                                style: TextStyle(
                                    fontFamily: 'Poppins Regular',
                                    color: Color(
                                        Utils.hexStringToHexInt('C4C4C4')),
                                    fontSize: width * 0.03),
                              ),
                              Text(
                                'Visit on 24 Jun, 10:00 AM',
                                style: TextStyle(
                                    fontFamily: 'Poppins Regular',
                                    color: Color(
                                        Utils.hexStringToHexInt('C4C4C4')),
                                    fontSize: width * 0.03),
                              )
                            ],
                          )


                        ],
                      ),

                      Column(
                        children: <Widget>[
                          Text(
                            '250',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: width * 0.02,
                                fontFamily: 'Poppins Regular'),
                          ),
                          Text(
                            'View All',
                            style: TextStyle(
                                color: Color(Utils.hexStringToHexInt('4285F4')),
                                fontSize: width * 0.02,
                                fontFamily: 'Poppins Regular'),
                          ),
                          Container(
                            padding: EdgeInsets.all(width * 0.003),
                            alignment: Alignment.center,
                            width: width * 0.1 + width * 0.09,
                            height: height * 0.05,
                            margin: EdgeInsets.only(right: width * 0.01),
                            decoration: BoxDecoration(
                                color: Color(Utils.hexStringToHexInt('4285F4')),
                                borderRadius: BorderRadius.circular(4)),
                            child: Text(
                              '8:00',
                              style: TextStyle(
                                  fontSize: width * 0.02,
                                  color: Colors.white,
                                  fontFamily: 'Poppins Regular'),
                            ),
                          ),
                        ],
                      )

                    ],
                  ),
                  SizedBox(
                    height: height * 0.01,
                  ),
                  Divider(
                    thickness: 1,
                    color: Colors.grey,
                  )
                ],
              ),
            ),
          );
        });
  }

  AppBar appBarr(BuildContext context, width, height) {
    return AppBar(
      centerTitle: true,
      backgroundColor: Color(Utils.hexStringToHexInt('46D0D9')),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.only(top: height * 0.05),
            child: Text(' Crossing Republick, Ghaziabad',
                style: TextStyle(
                    fontSize: width * 0.03,
                    fontFamily: 'Poppins Regular',
                    color: Colors.black),
                textAlign: TextAlign.center),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                width: width * 0.03,
                height: height * 0.03,
                child: SvgPicture.asset(
                  "images/svgicons/mappin.svg",
                ),
              ),
              Text(' Crossing Republick, Ghaziabad',
                  style: TextStyle(
                      fontSize: width * 0.02,
                      fontFamily: 'Poppins Regular',
                      color: Colors.black),
                  textAlign: TextAlign.center),
              IconButton(
                icon: Icon(
                  Icons.keyboard_arrow_down_sharp,
                  size: width * 0.05,
                  color: Colors.black,
                ),
                tooltip: 'Comment Icon',
                onPressed: () {},
              )
            ],
          ),
        ],
      ),
      actions: <Widget>[
        //IconButton
        IconButton(
          iconSize: width * 0.07,
          icon: const Icon(
            CupertinoIcons.bell,
            color: Colors.blue,
          ),
          tooltip: 'Setting Icon',
          onPressed: () {},
        ), //IconButton
      ],
      //<Widget>[]

      elevation: 0.0,
      leading: Builder(
        builder: (context) => IconButton(
          icon: const Icon(
            Icons.menu,
            color: Colors.black,
          ),
          tooltip: 'Menu Icon',
          onPressed: () => Scaffold.of(context).openDrawer(),
        ),
      ),
      brightness: Brightness.dark,
    );
  }
}
