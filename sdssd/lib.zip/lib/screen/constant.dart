import 'package:flutter/material.dart';

const Color bgLight = Color(0xff0B1623);
const Color bgDark = Color(0xff0D1018);